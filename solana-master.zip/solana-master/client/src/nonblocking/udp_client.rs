#[deprecated(
    since = "1.15.0",
    note = "Please use `solana_udp_client::nonblocking::udp_client::UdpClientConnection` instead."
)]
pub use solana_udp_client::nonblocking::udp_client::UdpClientConnection as UdpTpuConnection;
