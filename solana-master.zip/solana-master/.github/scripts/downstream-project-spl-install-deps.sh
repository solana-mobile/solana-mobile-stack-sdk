#!/usr/bin/env bash
set -e

sudo apt update
sudo apt install libudev-dev binutils-dev libunwind-dev protobuf-compiler -y
